import Firecrawl from "@mendable/firecrawl-js";
import * as cheerio from "cheerio";
import { parseArgs } from "node:util";

/**
 * Check the Price — Amazon India Product Scraper
 *
 * Scrapes one amazon.in product page and emits EXACTLY ONE clean product row:
 *
 *   { standard_link, title, category, price, mrp, image, updated }
 *
 * No affiliate_link, no run metadata, no nested "data" object — the stdout
 * JSON is the flat row the Google Sheets connection should receive.
 *
 * If the scrape fails, a CAPTCHA is served on every attempt, or any required
 * field (title, price, image) cannot be extracted, the script exits non-zero
 * WITHOUT writing anything to stdout, so no row (blank or otherwise) is ever
 * appended to the sheet.
 */

const apiKey = process.env.FIRECRAWL_API_KEY;
if (!apiKey) {
  console.error("FIRECRAWL_API_KEY is not set");
  process.exit(1);
}
const firecrawl = new Firecrawl({ apiKey });

const { values: flags } = parseArgs({
  strict: true,
  options: {
    url: { type: "string" }, // --url=https://www.amazon.in/dp/ASIN (required)
  },
});

if (!flags.url || flags.url.trim().length === 0) {
  console.error("--url is required (an amazon.in product page URL)");
  process.exit(1);
}

// --- URL validation + standard link ----------------------------------------

function extractAsin(u: URL): string | null {
  const m =
    u.pathname.match(/\/dp\/([A-Z0-9]{10})(?:[/?]|$)/i) ??
    u.pathname.match(/\/gp\/product\/([A-Z0-9]{10})(?:[/?]|$)/i) ??
    u.pathname.match(/\/gp\/aw\/d\/([A-Z0-9]{10})(?:[/?]|$)/i) ??
    u.pathname.match(/\/product\/([A-Z0-9]{10})(?:[/?]|$)/i);
  return m ? m[1].toUpperCase() : null;
}

let target: URL;
try {
  target = new URL(flags.url.trim());
} catch {
  throw new Error(`OUT_OF_SCOPE: not a valid URL: ${flags.url}`);
}
const host = target.hostname.toLowerCase();
if (host !== "amazon.in" && !host.endsWith(".amazon.in")) {
  throw new Error(`OUT_OF_SCOPE: not an amazon.in URL: ${flags.url}`);
}
const asin = extractAsin(target);
if (!asin) {
  throw new Error(
    `OUT_OF_SCOPE: not an amazon.in product page URL (no ASIN found in path): ${flags.url}`,
  );
}
const standardLink = `https://www.amazon.in/dp/${asin}`;

// --- extraction helpers ------------------------------------------------------

function cleanText(s: string | undefined | null): string | null {
  if (!s) return null;
  const t = s.replace(/\s+/g, " ").trim();
  return t.length > 0 ? t : null;
}

// "₹52,400.00" / "52,400" -> 52400
function parseInr(s: string | undefined | null): number | null {
  if (!s) return null;
  const cleaned = s.replace(/[^0-9.]/g, "");
  if (!cleaned) return null;
  const n = Number(cleaned);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function isCaptchaPage(html: string): boolean {
  return (
    /validateCaptcha/i.test(html) ||
    /Enter the characters you see below/i.test(html) ||
    /api-services-support@amazon\.com/i.test(html) ||
    /<title>\s*Robot Check\s*<\/title>/i.test(html)
  );
}

interface Extracted {
  title: string | null;
  category: string | null;
  price: number | null;
  mrp: number | null;
  image: string | null;
}

function extractProduct(html: string): Extracted {
  const $ = cheerio.load(html);

  const title = cleanText($("#productTitle").first().text());

  // Breadcrumb trail, e.g. "Electronics > Mobiles & Accessories > Smartphones";
  // fall back to the sub-nav category label when breadcrumbs are absent.
  const crumbs: string[] = [];
  $("#wayfinding-breadcrumbs_feature_div ul li a").each((_, el) => {
    const t = cleanText($(el).text());
    if (t) crumbs.push(t);
  });
  let category: string | null = crumbs.length > 0 ? crumbs.join(" > ") : null;
  if (!category) {
    category =
      cleanText($("#nav-subnav .nav-b").first().text()) ??
      cleanText($("#nav-subnav").attr("data-category"));
  }

  // Selling price: the buy-box price block first, then generic price nodes.
  let price =
    parseInr($("#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen").first().text()) ??
    parseInr(
      $("#corePriceDisplay_desktop_feature_div .a-price-whole").first().text(),
    ) ??
    parseInr($("#corePrice_feature_div .a-price .a-offscreen").first().text()) ??
    parseInr($("#priceblock_ourprice, #priceblock_dealprice").first().text());
  if (price === null) {
    price = parseInr(
      $("#centerCol .a-price:not(.a-text-price) .a-offscreen").first().text(),
    );
  }

  // MRP: the struck-through list price shown next to a discount.
  const mrp =
    parseInr(
      $("#corePriceDisplay_desktop_feature_div .basisPrice .a-offscreen").first().text(),
    ) ??
    parseInr(
      $('#centerCol .a-price.a-text-price[data-a-strike="true"] .a-offscreen').first().text(),
    ) ??
    parseInr($("#priceblock_listprice, .priceBlockStrikePriceString").first().text());

  // Main product image: prefer the hi-res variant when present.
  const imgEl = $("#landingImage, #imgBlkFront").first();
  let image =
    cleanText(imgEl.attr("data-old-hires")) ?? cleanText(imgEl.attr("src"));
  if (image && image.startsWith("data:")) {
    // Lazy-loaded placeholder — pull the largest candidate from the dynamic-image map.
    const dyn = imgEl.attr("data-a-dynamic-image");
    if (dyn) {
      try {
        const map = JSON.parse(dyn) as Record<string, unknown>;
        const urls = Object.keys(map);
        if (urls.length > 0) image = urls[0];
      } catch {
        image = null;
      }
    } else {
      image = null;
    }
  }

  return { title, category, price, mrp, image };
}

// --- scrape with CAPTCHA handling + proxy fallback ---------------------------

async function scrapeHtml(url: string, proxy: "auto" | "stealth"): Promise<string> {
  console.error(`Scraping ${url} (proxy: ${proxy})`);
  const res = (await firecrawl.scrape(url, {
    formats: ["rawHtml"],
    proxy,
    integration: "prometheus",
  } as Parameters<typeof firecrawl.scrape>[1])) as { rawHtml?: string; html?: string };
  return res.rawHtml ?? res.html ?? "";
}

async function main() {
  let html = "";
  let lastError: unknown = null;

  // First attempt with the default proxy; on CAPTCHA or scrape failure,
  // retry once through the stealth proxy.
  for (const proxy of ["auto", "stealth"] as const) {
    try {
      html = await scrapeHtml(standardLink, proxy);
    } catch (err) {
      lastError = err;
      console.error(
        `Scrape attempt failed (proxy: ${proxy}): ${err instanceof Error ? err.message : String(err)}`,
      );
      html = "";
      continue;
    }
    if (!html) {
      lastError = new Error("empty HTML response");
      console.error(`Empty HTML response (proxy: ${proxy}), retrying`);
      continue;
    }
    if (isCaptchaPage(html)) {
      lastError = new Error("CAPTCHA page served");
      console.error(`CAPTCHA detected (proxy: ${proxy}), retrying`);
      html = "";
      continue;
    }
    break;
  }

  if (!html) {
    throw new Error(
      `amazon.in scrape failed after proxy fallback (CAPTCHA or fetch error): ${
        lastError instanceof Error ? lastError.message : String(lastError)
      }`,
    );
  }

  const p = extractProduct(html);

  // Required fields — if any is missing, fail the run so NOTHING is sent to
  // Google Sheets (no blank row).
  const missing: string[] = [];
  if (!p.title) missing.push("title");
  if (p.price === null) missing.push("price");
  if (!p.image) missing.push("image");
  if (missing.length > 0) {
    throw new Error(
      `required product fields missing on amazon.in page (${missing.join(", ")}) — no row emitted`,
    );
  }

  // Exactly one clean product row; only these seven fields ever reach stdout.
  const row = {
    standard_link: standardLink,
    title: p.title,
    category: p.category,
    price: p.price,
    mrp: p.mrp ?? p.price,
    image: p.image,
    updated: new Date().toISOString(),
  };

  process.stdout.write(JSON.stringify(row));
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : String(err));
  process.exit(1);
});
